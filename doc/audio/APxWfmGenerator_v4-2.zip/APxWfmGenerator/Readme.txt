APx Waveform Generator Utility v4.2
===================================

This utility program can generate a variety of linear audio test waveforms for 
External Source (open loop) testing at a wide range of sample rates, channel 
counts and bit depths. For more information describing many of the 
specific signals, see the file "Audio Precision Test Signals on CD.pdf" in the 
"...\Audio Test Signals\" folder.

This utility program was created to alleviate the need of copying and 
transferring gigabytes of linear PCM audio files for external source testing. 
You are free to copy this utility to other computers or media, where you can 
generate the audio files you may need for external source testing.

The Waveform Generator Utility must be on a local drive to function. 
Instructions:

	1. Open ApxWfmGenerator.exe
	2. Select the Sample Rate for your signal generation.
	   Choose from common values from 8 kS/s to 192 kS/s.
	3. Select the number of Channels.
	   Choose from 1 to 16.
	4. Select the Resolution (bit depth).
	   Choose from 16, 20, 24 or 32 bits.
	5. Check the waveform(s) you want to create from
	   the "Waveforms" area.
	   Choose from sweeps, steady tones, and many
	   special waveforms. Note that the signal is 
	   the same on all channels, except for waveform
	   "Channel ID Multichannel".
	6. Choose an output folder.
	7. Click "Generate Waveforms".
	8. To view the files you have created, click
	   "Browse" or use Windows Explorer.

CAUTION: GENERATING THE WHOLE SET OF FILES AT HIGH SAMPLE RATES CAN REQUIRE 
GIGABYTES OF STORAGE. BE SURE YOUR OUTPUT FOLDER IS ON A DISK WITH SUFFICIENT 
SPACE AVAILABLE.

XIII0927133801